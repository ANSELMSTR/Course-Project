#include "server.h"

Server::Server(char* port)
{

     int socketFileDescriptor, clientSocketFD, portNumber, ack, queuesize;
     socklen_t clilen;
     char buffer[256];
     struct sockaddr_in serv_addr, cli_addr;

     portNumber = atoi(port);
     queuesize = 4; 

     cout << "Server started on port " << portNumber << endl;

	     if (port == NULL) {
		 cerr << "ERROR, no port provided\n" << endl;
		 exit(1);
	     }

     socketFileDescriptor = socket(AF_INET,SOCK_STREAM,0); 

	     if (socketFileDescriptor < 0) 
		cerr << "ERROR opening socket" << endl;

     bzero((char *) &serv_addr, sizeof(serv_addr)); 

     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portNumber);

	     if (bind(socketFileDescriptor, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) 
		      cerr << "ERROR on binding" << endl;

     listen(socketFileDescriptor,queuesize);
     clilen = sizeof(cli_addr);
     clientSocketFD = accept(socketFileDescriptor, (struct sockaddr *) &cli_addr, &clilen);

	     if (clientSocketFD < 0) 
		  cerr << "ERROR on accept" << endl;

     bzero(buffer,256);
     ack = read(clientSocketFD,buffer,255);

	     if (ack < 0) 
		cerr << "ERROR reading from socket" << endl;

    printf("%s\n",buffer);
 
    ack = write(clientSocketFD,"Acknowledge",12);

	     if (ack < 0) 
		cerr << "ERROR writing to socket" << endl;

     close(clientSocketFD);
     close(socketFileDescriptor);

}
