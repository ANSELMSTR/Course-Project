#include "client.h" 
#include <stdio.h>

Client::Client(char* hostname,char* port)
{
    int ack;
    struct hostent *server;
    char buffer[256] = "Hello";

    server = gethostbyname(hostname);

	    if (server == NULL) {
		cerr << "ERROR, no such host\n" << endl;
		exit(0);
	    }

	init(server,port);
	authenticate();

    ack = write(socketFD,buffer,strlen(buffer));
	    if (ack < 0) 
		 cerr << "ERROR writing to socket" << endl;

    bzero(buffer,256);
    ack = read(socketFD,buffer,255);
	    if (ack < 0) 
		 cerr << "ERROR reading from socket" << endl;

    printf("%s\n",buffer);

    close(socketFD);

}

void Client::init(struct hostent *server, char *port)
{
    portNumber = atoi(port);
    socketFD = socket(AF_INET, SOCK_STREAM, 0);
	    if (socketFD < 0) 
		cerr << "ERROR opening socket" << endl;


    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);

    serv_addr.sin_port = htons(portNumber);

}

// here initilize the serv_addr with bzero();
// and put the stuff  (AF_INET,htons(port), and server) 

void Client::authenticate() 
{
	    if (connect(socketFD,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) 
		cerr << "ERROR connecting\n" << endl;
}

// here call connect() and check for errors 
// nothing else ... I will add the authentication part 

void Client::sendMove(Move move)
{

	/** Note by Anselm: ?? I dont understand your comment here ??  **/

}

// this should call
// write(serverFD,&move,sizeof(move)); 
// check for errors





