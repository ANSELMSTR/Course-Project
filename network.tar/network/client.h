#ifndef client_h_
#define client_h_ 

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 

using namespace std;

	typedef struct packet {
	    int x; // coordinates of the move
	    int y;
	    int color; // color id of the player     
	} Move ;


class Client {
public:
	Client(char* host, char *port);
	void init(struct hostent *server, char *port);
	void authenticate();
	void sendMove(Move move);
	
private:
	int socketFD; //will hold the socket fileDescriptor
	int portNumber;
	struct sockaddr_in serv_addr;



};


#endif
