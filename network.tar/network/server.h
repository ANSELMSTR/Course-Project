/*
use the tutorial 
and setup a server which will listen for connections 
and when a connection happens , just print a message an quit ! 
*/

#ifndef server_h_
#define server_h_

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>

using namespace std;

class Server {
public:
	Server(char* port);
	
	
private:
	int listenSocket, connectedSocket;
	struct sockaddr_in *listen_addr, *client_addr;
	
};

#endif
