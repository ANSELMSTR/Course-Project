#include "client.h"
#include "server.h"


int main(int argc,char *argv[])
{
	if(argc == 3) //create a client
	{
		Client my_client(argv[1],argv[2]); // argv[1] = hostname, argv[2] = port	
	
	}
	else if(argc == 2) // create a server
	{
		Server my_server(argv[1]); // argv[1] = port
	}
	else
		cerr << "Use:\n- for client: argv[1] = hostname, argv[2] = port\n- for server: argv[1] = port\n" << endl;
	
	return 0;

}


